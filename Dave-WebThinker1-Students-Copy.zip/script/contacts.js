let validate = () => {
	// Fill in the necessary validation here
}